<?php
/**
 * counter.php
 * Backend bridge — menghindari CORS dengan memanggil CounterAPI
 * dari sisi server (bukan dari browser pengunjung).
 *
 * Cara kerja:
 *   Browser pengunjung --> counter.php (domain sendiri) --> api.counterapi.dev
 *
 * Upload file ini ke root direktori hosting (public_html / htdocs).
 */

// Izinkan hanya dari domain sendiri (opsional, tambah keamanan)
header('Content-Type: application/json');
header('Cache-Control: no-cache, no-store, must-revalidate');

// --- Konfigurasi ---
$COUNTER_URL = 'https://api.counterapi.dev/v1/gimm-portfolio-v2/neo-brutalism/up';

// --- Ambil data menggunakan cURL ---
$ch = curl_init();
curl_setopt_array($ch, [
    CURLOPT_URL            => $COUNTER_URL,
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_TIMEOUT        => 10,
    CURLOPT_FOLLOWLOCATION => true,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_HTTPHEADER     => ['Accept: application/json'],
]);

$response  = curl_exec($ch);
$http_code = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curl_err  = curl_error($ch);
curl_close($ch);

// --- Tangani error ---
if ($response === false || $curl_err || $http_code !== 200) {
    http_response_code(502);
    echo json_encode(['count' => 0, 'error' => 'upstream_failed']);
    exit;
}

// --- Teruskan respons asli dari CounterAPI ke browser ---
echo $response;
